//�r�[���p�`��X�N���v�g

var renderClass = "jp.ngt.rtm.render.WirePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.renderer);

function init(par1, par2)
{
  BeamL1 = renderer.registerParts(new Parts("BeamL1"));
  BeamL2 = renderer.registerParts(new Parts("BeamL2"));
  BeamR1 = renderer.registerParts(new Parts("BeamR1"));
  BeamR2 = renderer.registerParts(new Parts("BeamR2"));
}

function renderWireStatic(tileEntity, connection, vec, par8)
{
  
}

function renderWireDynamic(tileEntity, connection, vec, par8)
{
  var width = 1.0;
  var x = vec.getX();
  var y = vec.getY();
  var z = vec.getZ();
  var yaw = vec.getYaw();
  var pit = -vec.getPitch();
  var length = Math.sqrt(x*x+y*x+z*z);
  
  var maxPos = Math.floor(length/2/width)*2;
  var move = length/maxPos;
  var scale = (length/maxPos)/width;
  
  GL11.glPushMatrix();
   renderer.rotate(yaw,'Y',0,0,0);
   renderer.rotate(pit,'X',0,0,0);
   for(var i=0; i<maxPos; i=i+1){
     GL11.glPushMatrix();
     GL11.glTranslatef(0,0,move*i);
     GL11.glScalef(1,1,scale);
     renderBeam(i, maxPos, width);
     GL11.glPopMatrix();
   }
  GL11.glPopMatrix();
}

function renderBeam(pos, maxPos, width){
  var harfMaxPos = maxPos/2;
  if(pos==0) {
    GL11.glPushMatrix();
    GL11.glTranslatef(0,0,2*width);//���f����̃I�t�Z�b�g
    BeamR1.render(renderer);
    GL11.glPopMatrix();
  }
  if(1<=pos&&pos<harfMaxPos) {
    GL11.glPushMatrix();
    GL11.glTranslatef(0,0,1*width);//���f����̃I�t�Z�b�g
    BeamR2.render(renderer);
    GL11.glPopMatrix();
  }
  if(harfMaxPos<=pos&&pos<maxPos-1) {
    GL11.glPushMatrix();
    BeamL2.render(renderer);
    GL11.glPopMatrix();
  }
  if(pos==maxPos-1) {
    GL11.glPushMatrix();
    GL11.glTranslatef(0,0,-1*width);//���f����̃I�t�Z�b�g
    BeamL1.render(renderer);
    GL11.glPopMatrix();
  }
}