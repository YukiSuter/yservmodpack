
var renderClass = "jp.ngt.rtm.render.WirePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.renderer);

function init(par1, par2)
{
  wire = renderer.registerParts(new Parts("obj1"));
}

function renderWireStatic(tileEntity, connection, vec, par8)
{
  
}

function renderWireDynamic(tileEntity, connection, vec, par8)
{
  var x = vec.getX();
  var y = vec.getY();
  var z = vec.getZ();
  var yaw = vec.getYaw();
  var pit = -vec.getPitch();
  var length = Math.sqrt(x*x+y*x+z*z);
  var rate = length/4;
  
  GL11.glPushMatrix();
   renderer.rotate(yaw,'Y',0,0,0);
   renderer.rotate(pit,'X',0,0,0);
   GL11.glScalef(1,1,rate);
   wire.render(renderer);
  GL11.glPopMatrix();
}