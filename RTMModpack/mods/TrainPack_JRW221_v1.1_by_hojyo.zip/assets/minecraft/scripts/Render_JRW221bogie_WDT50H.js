var renderClass = "jp.ngt.rtm.render.VehiclePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.math);

function init(par1, par2)
{
	frame = renderer.registerParts(new Parts("frame"));
	snowplow = renderer.registerParts(new Parts("snowplow"));
	wheel1 = renderer.registerParts(new Parts("wheel1"));
	wheel2 = renderer.registerParts(new Parts("wheel2"));
	
	var ModelName = renderer.getModelName();
	
	if(ModelName.contains("mc") || ModelName.contains("mp") || ModelName.contains("mn")){
		yawdamper = renderer.registerParts(new Parts("yawdamper2"));
	}else if(ModelName.contains("tc")){
		yawdamper = renderer.registerParts(new Parts("yawdamper1l"));
	}else{
		yawdamper = renderer.registerParts(new Parts("yawdamper1r"));
	}
}

function render(entity, pass, par3)
{
	var f0 = renderer.getWheelRotationR(entity);
	var y0 = -0.5694;
	var z1 = 1.05;
	var z2 = -1.05;

	GL11.glPushMatrix();

	frame.render(renderer);
	snowplow.render(renderer);
	yawdamper.render(renderer);

	GL11.glPushMatrix();
	renderer.rotate(f0, 'X', 0.0, y0, z1);
	wheel1.render(renderer);
	GL11.glPopMatrix();

	GL11.glPushMatrix();
	renderer.rotate(f0, 'X', 0.0, y0, z2);
	wheel2.render(renderer);
	GL11.glPopMatrix();

	GL11.glPopMatrix();
}
