var renderClass = "jp.ngt.rtm.render.VehiclePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.math);


function init(par1, par2)
{
	body = renderer.registerParts(new Parts("body", "cab", "window"));
	acc = renderer.registerParts(new Parts("partition", "strap", "rack2", "hood", "couplerF", "couplerB", "JumperLine", "seatbase", "signmesh"));
	light = renderer.registerParts(new Parts("light"));
	doorLF = renderer.registerParts(new Parts("door_LF"));
	doorLB = renderer.registerParts(new Parts("door_LB"));
	doorRF = renderer.registerParts(new Parts("door_RF"));
	doorRB = renderer.registerParts(new Parts("door_RB"));
	pantabase = renderer.registerParts(new Parts("panta_AB1", "panta_AB2", "panta_B1", "panta_B2", "RunBoard_pantaB"));
	pantaB11 = renderer.registerParts(new Parts("panta_B1_1"));
	pantaB12 = renderer.registerParts(new Parts("panta_B1_2"));
	pantaB13 = renderer.registerParts(new Parts("panta_B1_3"));
	pantaB14 = renderer.registerParts(new Parts("panta_B1_4"));
	pantaB15 = renderer.registerParts(new Parts("panta_B1_5"));
	pantaB21 = renderer.registerParts(new Parts("panta_B2_1"));
	pantaB22 = renderer.registerParts(new Parts("panta_B2_2"));
	pantaB23 = renderer.registerParts(new Parts("panta_B2_3"));
	pantaB24 = renderer.registerParts(new Parts("panta_B2_4"));
	pantaB25 = renderer.registerParts(new Parts("panta_B2_5"));
	seat1 = renderer.registerParts(new Parts("seat1"));
	seat2 = renderer.registerParts(new Parts("seat2"));
	seat3 = renderer.registerParts(new Parts("seat3"));
	seat4 = renderer.registerParts(new Parts("seat4"));
	seat5 = renderer.registerParts(new Parts("seat5"));
	seat6 = renderer.registerParts(new Parts("seat6"));
	seat7 = renderer.registerParts(new Parts("seat7"));
	seat8 = renderer.registerParts(new Parts("seat8"));
	Crv = renderer.registerParts(new Parts("c_rev"));
	Cmc = renderer.registerParts(new Parts("c_mc"));
	Cbr = renderer.registerParts(new Parts("c_br"));
	
	var ModelName = renderer.getModelName();
	
	//クーラー判定
	if(ModelName.contains("cl1")){
		cooler = renderer.registerParts(new Parts("cooler_A1"));
	}else if(ModelName.contains("cl2")){
		cooler = renderer.registerParts(new Parts("cooler_A2"));
	}else{
		cooler = renderer.registerParts(new Parts("none")); //非冷房
	}
	
	//スカート判定
	if(ModelName.contains("tc")){
		var isTc = "_tc";
	}else{
		var isTc = "";
	}
	if(ModelName.contains("sk1")){
		skirt = renderer.registerParts(new Parts("skirt1"+isTc));
	}else if(ModelName.contains("sk2")){
		skirt = renderer.registerParts(new Parts("skirt2"+isTc));
	}else if(ModelName.contains("sk3")){
		skirt = renderer.registerParts(new Parts("skirt3"+isTc));
	}else{
		skirt = renderer.registerParts(new Parts("none")); //はいてない
	}
	
	//先頭幌判定
	if(ModelName.contains("hr")){
		var isHoro = "fronthoro";
	}else{
		var isHoro = "none";
	}
	
	//車種判定
	if(ModelName.contains("tc")){
		typeparts = renderer.registerParts(new Parts("bottom(ECt)", "bead_T", "wc", isHoro)); //クハ
	}else if (ModelName.contains("mc")){
		typeparts = renderer.registerParts(new Parts("bottom(EC)", "bead_M", "seatbase_wc", "FuseBox", "duct", "mc_vent", isHoro)); //クモハ
	}else if (ModelName.contains("mp")){
		typeparts = renderer.registerParts(new Parts("bottom(EC)", "bead_M", "seatbase_wc", "FuseBox", "duct")); //モハ
	}else if (ModelName.contains("mn")){
		typeparts = renderer.registerParts(new Parts("bottom(EC)", "bead_T", "seatbase_wc", "duct")); //ﾉｰﾊﾟﾝモハ
	}else{
		typeparts = renderer.registerParts(new Parts("bottom(ECt)", "bead_T", "seatbase_wc")); //サハ
	}
	
}


function render(entity, pass, par3)
{
	var ModelName = "0",
		notch = 0.0,
		doorMoveL = 0.0,
		doorMoveR = 0.0,
		pantaRotate1 = 0.0,
		pantaRotate2 = 0.0,
		seatRotate = 0.0,
		roMc = 0.0,
		roBr = 0.0,
		roRv = 0.0;

	if(entity != null){
		ModelName =renderer.getModelName();
		notch = entity.getNotch();
		doorMoveL = renderer.sigmoid(entity.doorMoveL / 60) * 0.65;
		doorMoveR = renderer.sigmoid(entity.doorMoveR / 60) * 0.65;
		pantaRotate1 =renderer.sigmoid(entity.pantograph_F / 60) * 27 * 1.2;
		pantaRotate2 =renderer.sigmoid(entity.pantograph_F / 60) * 66 * 1.2;
		seatRotate = renderer.sigmoid(entity.seatRotation / 60) * 30;
	}


	GL11.glPushMatrix();
	
	if(pass == 0 || pass == 1){
	
//車体
	body.render(renderer);
	acc.render(renderer);
	cooler.render(renderer);
	skirt.render(renderer);
	typeparts.render(renderer);

//ドア
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, doorMoveL);
	doorLF.render(renderer);
	GL11.glPopMatrix();
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, -doorMoveL);
	doorLB.render(renderer);
	GL11.glPopMatrix();
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, doorMoveR);
	doorRF.render(renderer);
	GL11.glPopMatrix();
	GL11.glPushMatrix();
	GL11.glTranslatef(0.0, 0.0, -doorMoveR);
	doorRB.render(renderer);
	GL11.glPopMatrix();

//パンタ
	if(ModelName.contains("mc") || ModelName.contains("mp")){
	pantabase.render(renderer);
	//パンタB1
		GL11.glPushMatrix();
		renderer.rotate(pantaRotate1, 'X', 0.0, 2.8784, 6.4776);
		pantaB11.render(renderer);
		renderer.rotate(-pantaRotate2, 'X', 0.0, 3.8526, 7.9300);
		pantaB12.render(renderer);
		renderer.rotate(pantaRotate2 - pantaRotate1, 'X', 0.0, 4.6227, 7.0229);
		pantaB13.render(renderer);
		GL11.glPopMatrix();
		GL11.glPushMatrix();
		renderer.rotate(-pantaRotate1, 'X', 0.0, 2.8784, 7.5224);
		pantaB14.render(renderer);
		renderer.rotate(pantaRotate2, 'X', 0.0, 3.8526, 6.0700);
		pantaB15.render(renderer);
		GL11.glPopMatrix();
	//パンタB2
		GL11.glPushMatrix();
		renderer.rotate(pantaRotate1, 'X', 0.0, 2.8784, -7.5224);
		pantaB21.render(renderer);
		renderer.rotate(-pantaRotate2, 'X', 0.0, 3.8526, -6.0700);
		pantaB22.render(renderer);
		renderer.rotate(pantaRotate2 - pantaRotate1, 'X', 0.0, 4.6227, -6.9771);
		pantaB23.render(renderer);
		GL11.glPopMatrix();
		GL11.glPushMatrix();
		renderer.rotate(-pantaRotate1, 'X', 0.0, 2.8784, -6.4776);
		pantaB24.render(renderer);
		renderer.rotate(pantaRotate2, 'X', 0.0, 3.8526, -7.9300);
		pantaB25.render(renderer);
		GL11.glPopMatrix();
	}
	
//座席
	GL11.glPushMatrix();
	renderer.rotate(seatRotate, 'X', 0.0, -0.25, 4.85);
	seat1.render(renderer);
	GL11.glPopMatrix();
		GL11.glPushMatrix();
		renderer.rotate(seatRotate, 'X', 0.0, -0.25, 3.95);
		seat2.render(renderer);
		GL11.glPopMatrix();
	GL11.glPushMatrix();
	renderer.rotate(seatRotate, 'X', 0.0, -0.25, 3.05);
	seat3.render(renderer);
	GL11.glPopMatrix();
		GL11.glPushMatrix();
		renderer.rotate(seatRotate, 'X', 0.0, -0.25, 2.15);
		seat4.render(renderer);
		GL11.glPopMatrix();
	GL11.glPushMatrix();
	renderer.rotate(seatRotate, 'X', 0.0, -0.25, -2.15);
	seat5.render(renderer);
	GL11.glPopMatrix();
		GL11.glPushMatrix();
		renderer.rotate(seatRotate, 'X', 0.0, -0.25, -3.05);
		seat6.render(renderer);
		GL11.glPopMatrix();
	GL11.glPushMatrix();
	renderer.rotate(seatRotate, 'X', 0.0, -0.25, -3.95);
	seat7.render(renderer);
	GL11.glPopMatrix();
		GL11.glPushMatrix();
		renderer.rotate(seatRotate, 'X', 0.0, -0.25, -4.85);
		seat8.render(renderer);
		GL11.glPopMatrix();

//操作機器
	if(notch > 0){
		roMc = notch * -18;
		roBr = -90;
		roRv = 20.0;
	}else{
		roMc = 0.0;
		roBr = notch * -11 - 90;
		roRv = 0.0;
	}
	
	GL11.glPushMatrix();
	renderer.rotate(roMc, 'X', 0.0, 0.9343, 9.05);
	Cmc.render(renderer);
	GL11.glPopMatrix();
	
	GL11.glPushMatrix();
	renderer.rotate(roBr, 'X', 0.0, 0.9343, 9.05);
	Cbr.render(renderer);
	GL11.glPopMatrix();
	
	GL11.glPushMatrix();
	renderer.rotate(roRv, 'X', 0.0, 0.95, 9.142);
	Crv.render(renderer);
	GL11.glPopMatrix();
	
	}
	
//ライト描画
	if(pass == 2 || pass == 3 || pass == 4){ light.render(renderer); }

	GL11.glPopMatrix();

}
