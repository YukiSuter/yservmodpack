var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2)
{
	main = renderer.registerParts(new Parts("led1", "led2", "side panel", "silver", "Yellow", "ash", "monitor", "lamp", "door_sil", "accent color", "IC", "submonitor", "lamp2", "black", "illustration", "sensor", "door"));
	doorL = renderer.registerParts(new Parts("door-l"));
	doorR = renderer.registerParts(new Parts("door-r"));
}

function render(entity, pass, par3)
{
	GL11.glPushMatrix();

	if(pass == 0)
	{
		main.render(renderer);

		var state = renderer.getMovingCount(entity);
		if(state > 0.0)
		{
			GL11.glPushMatrix();
			renderer.rotate(-90.0, 'Y', -0.519, 0.625, -0.7678);
			doorL.render(renderer);
			GL11.glPopMatrix();

			GL11.glPushMatrix();
			renderer.rotate(90.0, 'Y', 0.317, 0.625, -0.7678);
			doorR.render(renderer);
			GL11.glPopMatrix();
		}
		else
		{
			doorL.render(renderer);
			doorR.render(renderer);
		}
	}

	GL11.glPopMatrix();
}
