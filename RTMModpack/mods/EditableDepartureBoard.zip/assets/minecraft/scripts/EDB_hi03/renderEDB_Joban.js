var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.ngtlib.renderer);
importPackage(Packages.jp.ngt.rtm.render);

importPackage(Packages.net.minecraft.tileentity);
importPackage(Packages.jp.ngt.ngtlib.io);
importPackage(Packages.jp.ngt.ngtlib.util);
importPackage(Packages.net.minecraft.command.server);
importPackage(Packages.net.minecraft.init);
importClass(java.util.HashMap);
importPackage(Packages.jp.ngt.rtm.electric);

var ErrorData = new HashMap();

function init(par1, par2) {
    base = renderer.registerParts(new Parts("obj1"));
    distList = [//�s������ォ�珇�ɏ��� ��Ԃ͌������s���ɂ��\�������
        "���\��", "�i��", "���", "����", "�䑷�q", "���", "���c",
        "�y�Y", "����", "���c", "����", "����", "���킫"
    ];
    typeList = [
        "���\��","����","����","���}", "���ʉ���"
    ];
    nameList = [
        "���\��", "�Ђ���", "�Ƃ���"
    ];
    optionList = [
        "���\��", "��֐�Y", "��֐�G","��쓌�����C��", "4�h�A"
    ];
    lineList = [
        "���\��"
    ];
    info = {
        posX: -1.2518,//���W�͕\�����鍶��̍��W�����
        posY: 0.5679,
        posZ: 0.1741,
        pitch: 0.2363,//pitch��2�i�߂̍����_�܂ł̒���
        height: 0.2363,//height�͕\�����镶���̍���(pitch�ƍ�������ƕ����̉��̌��Ԃ��ł���)
        row: 3//�\������i�� �ŉ��i�͐ڋ߂�x���̕\��������Ƃ��͂��̕\�����o��
    };
    uv = {
        //UV�̒�` �c�̍����͓����ɂ��Ă������� �p�ӂ��ĂȂ����̂�[0, 0]�ɂ��� [minU, maxU]
        //�d���f���ɕ\��������̂͏�ʂɍ��킹�邱��
        pitchV: 32 / 1024,
        time: [0, 16 / 1024],
        dist: [16 / 1024, 128 / 1024],
        type: [128 / 1024, 192 / 1024],
        track: [368 / 1024, 400 / 1024],
        cars: [208 / 1024, 272 / 1024],
        name: [272 / 1024, 368 / 1024],
        rank: [400 / 1024, 432 / 1024],
        delay: [432 / 1024, 544 / 1024],
        option: [544 / 1024, 640 / 1024],
        line: [0, 0],
        door: [0, 0],

        //[[����uv][�E��uv]]
        approaching: [[0, 544 / 1024], [224 / 1024, 576 / 1024]],
        delayAnnounce: [[0, 576 / 1024], [432 / 1024, 608 / 1024]]
    };
}

function render(entity, pass, par3) {
    if (0 <= pass || pass <= 2) {
        GL11.glPushMatrix();
        base.render(renderer);
        GL11.glPopMatrix();

        if (entity === null) return;
        
        var error = ErrorData.get(entity);
        if (error === null) {
            ErrorData.put(entity, {});
            error = {};
        }

        if (error.isError) {
            if (!error.drawed) {
                var player = NGTUtil.getClientPlayer();
                var pos = [Math.floor(entity.field_145851_c), Math.floor(entity.field_145848_d), Math.floor(entity.field_145849_e)];

                NGTLog.sendChatMessage(player, "��b[EditableDepSign] ��c�G���[���������܂���");
                NGTLog.sendChatMessage(player, "Pos:" + pos.join(", "));
                NGTLog.sendChatMessage(player, "Info:��e" + error.info);
                if (error.hasStackTrace) {
                    //NGTLog.sendChatMessage(player, "Error:" + error.error);
                    NGTLog.sendChatMessage(player, "StackTrace:" + error.stackTrace);
                }
                NGTLog.sendChatMessage(player, "--------------------------------------");
            }
            error.drawed = true;
            ErrorData.put(entity, error);
        }
        else {
            error.drawed = false;
            error.hasStackTrace = false;
            ErrorData.put(entity, error);
        }
        //ErrorData.put(entity, error);

        try {

            //�R�}�u���擾
            var commandBlock = searchTileEntity(entity, TileEntityCommandBlock);
            var command = null;
            if (commandBlock !== null) {
                command = NGTUtil.getField(CommandBlockLogic.class, commandBlock.func_145993_a(), ["Command", "field_145763_e"]);
            }
            //private�ȃt�B�[���h���擾���� (class, instance, ["MCP Name", "SRG Name"])

            //�R�l�N�^�擾
            var connectorBlock = searchTileEntity(entity, TileEntityInsulator);
            var signal = 0;
            if (connectorBlock !== null) {
                signal = NGTUtil.getField(TileEntityElectricalWiring.class, connectorBlock, "signal");
            }

            //�����ē��u���b�N
            var approachingBlock = Blocks.field_150340_R;//���u���b�N
            var isApproaching = searchBlockAndMeta(entity, approachingBlock, null)[0] !== null;

            //�x���ē��u���b�N
            var delayBlockData = Blocks.field_150425_aM;//�\�E���T���h
            var delayBlock = searchBlockAndMeta(entity, delayBlockData, null);
            var isDelaying = delayBlock[0] !== null;

            //json�ϊ�
            if (command === null || command === error.command || command === "") {
                error.command = command;
                error.isError = false;
                error.drawed = false;
                error.hasStackTrace = false;
                ErrorData.put(entity, error);
                return;
            }
            var cb;
            try { cb = JSON.parse(command); }
            catch (e) {
                error.command = command;
                error.isError = true;
                error.hasStackTrace = true;
                error.error = e;
                error.stackTrace = e.stack;
                error.info = "json��̓G���[";
                ErrorData.put(entity, error);
                return;
            }

            //�f�[�^�`�F�b�N
            if (cb.style === undefined) {
                error.isError = true;
                error.info = "json��style���ݒ肳��Ă��܂���";
                error.command = command;
                ErrorData.put(entity, error);
                return;
            }
            if (cb.list === undefined) {
                error.isError = true;
                error.info = "json��list���ݒ肳��Ă��܂���";
                error.command = command;
                ErrorData.put(entity, error);
                return;
            }
            if (cb.setting === undefined) {
                error.isError = true;
                error.info = "json��setting���ݒ肳��Ă��܂���";
                error.command = command;
                ErrorData.put(entity, error);
                return;
            }
            if (cb.grid === undefined) {
                error.isError = true;
                error.info = "json��grid���ݒ肳��Ă��܂���";
                error.command = command;
                ErrorData.put(entity, error);
                return;
            }
            var grid = cb.grid;

            //���Ԏ擾
            var time = (renderer.getMCTime() + 6000) % 24000 * 3.6;
            if (cb.setting.realTime) time = (renderer.getSystemTime() + 9 * 3600) % 86400;
            var delayTime = 0;
            if (isDelaying) {
                switch (delayBlock[1]) {
                    case 0: delayTime = 3 * 60; break;
                    case 1: delayTime = 5 * 60; break;
                    case 2: delayTime = 10 * 60; break;
                    case 3: delayTime = 30 * 60; break;
                }
            }

            //��Ԑڋ�
            var arrivingRow = 0;
            var tick = renderer.getTick(entity);
            if (isApproaching || signal === 1) {
                arrivingRow = 1;
                if (tick % 20 < 10) {
                    (function () {
                        var x = -(info.height / 2 * (grid.approaching / 2));
                        var y = info.posY - info.pitch * (info.row - 1);
                        var z = info.posZ;
                        var vx = [[[x, y, z], [-x, y - info.pitch, z]]];
                        var uvAry = [uv.approaching];
                        renderVartexListWithUV(vx, uvAry);
                    })();
                }
            }
            else if (isDelaying){
                arrivingRow = 1;
                (function () {
                    var x = -(info.height / 2 * (grid.delay / 2));
                    var y = info.posY - info.pitch * (info.row - 1);
                    var z = info.posZ;
                    var vx = [[[x, y, z], [-x, y - info.pitch, z]]];
                    var uvAry = [uv.delayAnnounce];
                    renderVartexListWithUV(vx, uvAry);
                })();
            }

            //info�`��
            var w = info.height / 2;
            var rowCount = 0;
            var offsetX;
            var offsetY = 0;
            for (var cListIdx = 0; cListIdx < cb.list.length; cListIdx++) {
                var timeIdx = cb.style.indexOf("time");
                if (timeIdx === -1) {
                    error.isError = true;
                    error.info = "style��time������܂���";
                    error.command = command;
                    ErrorData.put(entity, error);
                    return;
                }
                //���Ԕ���
                var trainTime = decordTime(cb.list[cListIdx][timeIdx]) + delayTime;
                var offsetTime = 21 * 3600;
                if ((trainTime + offsetTime) % 86400 >= (time + offsetTime) % 86400) {
                    offsetX = 0;
                    for (var styleIdx = 0; styleIdx < cb.style.length; styleIdx++) {
                        if (uv[cb.style[styleIdx]] === undefined) {
                            error.isError = true;
                            error.info = "style�ɖ���`�̖��O������܂�->" + cb.style[styleIdx];
                            error.command = command;
                            ErrorData.put(entity, error);
                            return;
                        }
                        if (grid[cb.style[styleIdx]] === undefined) grid[cb.style[styleIdx]] = 0;
                        var wSize = w * grid[cb.style[styleIdx]];
                        renderPanel(cb.style[styleIdx], cb.list[cListIdx][styleIdx], info.posX + offsetX, info.posY - offsetY, info.posZ, wSize, isDelaying, entity, delayBlock[1]);
                        offsetX += w * grid.space;
                        if (grid[cb.style[styleIdx]] === undefined) grid[cb.style[styleIdx]] = 1;
                        offsetX += wSize;
                    }
                    rowCount++;
                    offsetY += info.pitch;
                    if (rowCount >= info.row - arrivingRow) break;
                }
            }
        }
        catch (e) {
            error.isError = true;
            error.hasStackTrace = true;
            error.error = e;
            error.stackTrace = e.stack;
            error.info = "�s���ȃG���[";
            error.command = command;
            ErrorData.put(entity, error);
        }
    }
}

/*
�\���̎��
   #time
   #dist
   #type
   #track
   #cars
   #name
   #rank
   #trainNo
 */
function renderPanel(type, data, x, y, z, w, isDelayg, entity, delayMat) {
    var vx = [];
    var uvAry = [];
    var x2 = x + w;
    var y2 = y - info.height;
    var vIdx = 0;
    var wt = w / 5;
    if (type === "time") {
        if (checkTime(data)) {
            var t = data.replace(/:/g, "");
            var t1 = Math.floor(t / 100000) % 10;
            var t2 = Math.floor(t / 10000) % 10;
            var t3 = Math.floor(t / 1000) % 10;
            var t4 = Math.floor(t / 100) % 10;
            vx = [
                [[x, y, z], [x + wt, y - info.height, z]],
                [[x + wt, y, z], [x + wt * 2, y2, z]],
                [[x + wt * 2, y, z], [x + wt * 3, y2, z]],
                [[x + wt * 3, y, z], [x + wt * 4, y2, z]],
                [[x + wt * 4, y, z], [x + wt * 5, y2, z]]
            ];
            uvAry = [
                [[uv.time[0], 0 + uv.pitchV * t1], [uv.time[1], uv.pitchV + uv.pitchV * t1]],
                [[uv.time[0], 0 + uv.pitchV * t2], [uv.time[1], uv.pitchV + uv.pitchV * t2]],
                [[uv.time[0], 0 + uv.pitchV * 10], [uv.time[1], uv.pitchV + uv.pitchV * 10]],
                [[uv.time[0], 0 + uv.pitchV * t3], [uv.time[1], uv.pitchV + uv.pitchV * t3]],
                [[uv.time[0], 0 + uv.pitchV * t4], [uv.time[1], uv.pitchV + uv.pitchV * t4]]
            ];
            if (t1 === 0) {
                uvAry.shift();
                vx.shift();
            }
            if (isDelayg && renderer.getTick(entity) % 120 < 60) {
                vx = [[[x, y, z], [x + w, y - info.height, z]]];
                uvAry = [[[uv.delay[0], 0 + uv.pitchV * delayMat], [uv.delay[1], uv.pitchV + uv.pitchV * delayMat]]];
            }
        }
    }
    else if (type === "trainNo") {
        if (checkNumber(data)) {
            var n1 = Math.floor(data / 100) % 10;
            var n2 = Math.floor(data / 10) % 10;
            var n3 = Math.floor(data) % 10;
            vx = [
                [[x, y, z], [x + wt, y - info.height, z]],
                [[x + wt, y, z], [x + wt * 2, y2, z]],
                [[x + wt * 2, y, z], [x + wt * 3, y2, z]]
            ];
            uvAry = [
                [[uv.time[0], 0 + uv.pitchV * n1], [uv.time[1], uv.pitchV + uv.pitchV * n1]],
                [[uv.time[0], 0 + uv.pitchV * n2], [uv.time[1], uv.pitchV + uv.pitchV * n2]],
                [[uv.time[0], 0 + uv.pitchV * n3], [uv.time[1], uv.pitchV + uv.pitchV * n3]]
            ];
            if (n1 === 0) {
                uvAry.shift();
                vx.shift();
                if (n2 === 0) {
                    uvAry.shift();
                    vx.shift();
                }
            }
        }
    }
    else {
        //��������
        //�����ŗv�f��ǉ�����ꍇ�͂����ɏ���������
        //���̍ۂ�init()��uv�ɂ���`��ǉ�����
        //
        //type = style��glid�Ŏg�p����閼�O
        //data = json��list�ɏ����ꂽ�Ή�����f�[�^��n��
        //vIdx = UV�̂���V�̃C���f�b�N�X��n��(�e�N�X�`���̕\�����e�̏ォ�牽�Ԗڂ�������)
        //distList = init�Œ�`�����s����̔z��
        //typeList = init�Œ�`������ʂ̔z��
        //���ɂ�init()�ɒ�`���邱�ƂŔz����Q�Ƃ��邱�Ƃ��ł���

        if (type === "dist") {
            if (checkString(data)) {
                vIdx = distList.indexOf(data);
            }
        }
        if (type === "type") {
            if (checkString(data)) {
                vIdx = typeList.indexOf(data);
            }
        }
        if (type === "track") {
            if (checkNumber(data)) {
                vIdx = data;
            }
        }
        if (type === "cars") {
            if (checkNumber(data)) {
                vIdx = data;
            }
        }
        if (type === "name") {
            if (checkString(data)) {
                vIdx = nameList.indexOf(data);
            }
        }
        if (type === "rank") {
            if (checkNumber(data)) {
                vIdx = data;
            }
        }
        if (type === "option") {
            if (checkString(data)) {
                vIdx = optionList.indexOf(data);
            }
        }
        if (type === "line") {
            if (checkString(data)) {
                vIdx = lineList.indexOf(data);
            }
        }
        if (type === "door") {
            if (checkNumber(data)) {
                vIdx = data;
            }
        }
        if (vIdx <= -1) vIdx = 0;
        vx = [[[x, y, z], [x2, y2, z]]];
        uvAry = [[[uv[type][0], 0 + uv.pitchV * vIdx], [uv[type][1], uv.pitchV + uv.pitchV * vIdx]]];
    }

    renderVartexListWithUV(vx, uvAry);
}

function decordTime(time) {
    var t = String(time).split(":");
    if (t.length !== 3) return null;
    return (t[0] * 3600 + t[1] * 60 + t[2] * 1) % 86400;
}

function renderVartexListWithUV(vartexs, uvList) {
    if (vartexs.length === 0 || uvList.length === 0) return;

    GL11.glPushMatrix();
    var tessellator = NGTTessellator.instance;
    for (var i = 0; i < vartexs.length; i++) {
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(vartexs[i][0][0], vartexs[i][0][1], vartexs[i][0][2], uvList[i][0][0], uvList[i][0][1]);
        tessellator.addVertexWithUV(vartexs[i][0][0], vartexs[i][1][1], vartexs[i][0][2], uvList[i][0][0], uvList[i][1][1]);
        tessellator.addVertexWithUV(vartexs[i][1][0], vartexs[i][1][1], vartexs[i][1][2], uvList[i][1][0], uvList[i][1][1]);
        tessellator.addVertexWithUV(vartexs[i][1][0], vartexs[i][0][1], vartexs[i][1][2], uvList[i][1][0], uvList[i][0][1]);
        tessellator.draw();
    }
    GL11.glPopMatrix();
}
function checkTime(time) {
    var t = String(time).split(":");
    if (t.length !== 3) return false;
    for (var i = 0; i < t.length; i++) {
        if (isNaN(Number(t[i]))) return false;
    }
    return true;
}

function checkString(str) {
    if (checkTime(str)) return false;
    return typeof str === "string";
}

function checkNumber(num) {
    return typeof num === "number";
}

//metadata��null��^����ƑSmetadata���ΏۂɂȂ�
//�Ԃ�l:[block(Block�^), meta(Int�^)]
function searchBlockAndMeta(entity, blockType, metadata) {
    var x = Math.floor(entity.field_145851_c);
    var y = Math.floor(entity.field_145848_d);
    var z = Math.floor(entity.field_145849_e);
    var searchMaxCount = 32;//����[��
    var world = entity.func_145831_w();
    for (var i = 1; i <= searchMaxCount; i++) {
        var block = world.func_147439_a(x, y - i, z);
        if (block === blockType) {
            if (metadata !== null) {
                if (world.func_72805_g(x, y - i, z) === metadata) return [block, world.func_72805_g(x, y - i, z)];
            }
            return [block, world.func_72805_g(x, y - i, z)];
        }
    }
    return [null, 0];
}

function searchTileEntity(entity, typeName) {
    var x = Math.floor(entity.field_145851_c);
    var y = Math.floor(entity.field_145848_d);
    var z = Math.floor(entity.field_145849_e);
    var searchMaxCount = 32;//����[��
    var world = entity.func_145831_w();
    for (var i = 1; i <= searchMaxCount; i++) {
        var block = world.func_147438_o(x, y - i, z);
        if (block instanceof typeName) return block;
    }
    return null;
}