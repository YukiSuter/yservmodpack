var renderClass = "jp.ngt.rtm.render.SignalPartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2)
{
	body = renderer.registerParts(new Parts("body"));
	light1 = renderer.registerParts(new Parts("light1"));
	light2 = renderer.registerParts(new Parts("light2"));
	light3 = renderer.registerParts(new Parts("light3"));
	light4 = renderer.registerParts(new Parts("light4"));
	light5 = renderer.registerParts(new Parts("light5"));
}

function render(entity, pass, par3)
{
  
  var signal = entity==null? 0 : entity.getSignal();
  
  if(pass == 0) body.render(renderer);
  
  if(signal==1&&pass==2){
    switch(rotate(entity)){
      case 1:light1.render(renderer);light2.render(renderer);break;
      case 2:light2.render(renderer);light3.render(renderer);break;
      case 3:light3.render(renderer);light4.render(renderer);break;
      case 4:light4.render(renderer);light5.render(renderer);break;
      case 5:light5.render(renderer);light1.render(renderer);break;
    }
  }
}

function rotate(entity){
  if(entity==null) return 0;
  var tick = entity.tick,
      max = 20,
      f = tick % max;
  if(f>=max*(0/5)&&f<=max*(1/5)) return 1;
  if(f>=max*(1/5)&&f<=max*(2/5)) return 2;
  if(f>=max*(2/5)&&f<=max*(3/5)) return 3;
  if(f>=max*(3/5)&&f<=max*(4/5)) return 4;
  if(f>=max*(4/5)&&f<=max*(5/5)) return 5;
}