var renderClass = "jp.ngt.rtm.render.SignalPartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2)
{
	body = renderer.registerParts(new Parts("body"));
	light1 = renderer.registerParts(new Parts("light1"));
	light2 = renderer.registerParts(new Parts("light2"));
	light3 = renderer.registerParts(new Parts("light3"));
	light4 = renderer.registerParts(new Parts("light4"));
}

function render(entity, pass, par3)
{
  
  var signal = entity==null? 0 : entity.getSignal();
  
  if(pass == 0) body.render(renderer);
  
  if(signal==0) if(pass == 2) light1.render(renderer);
  if(signal==1) if(pass == 2) light2.render(renderer);
  if(signal==2) if(pass == 2) light3.render(renderer);
  if(signal==3) if(pass == 2) light4.render(renderer);
}