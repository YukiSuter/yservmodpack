var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2)
{
	body = renderer.registerParts(new Parts("body"));
	light1 = renderer.registerParts(new Parts("light1"));
	light2 = renderer.registerParts(new Parts("light2"));
}

function render(entity, pass, par3)
{
  var state = renderer.getLightState(entity);
  
  if(pass == 0) body.render(renderer);
  
  if(state==1){
    if(pass == 0) light2.render(renderer);
    if(lightF1(entity)){
      if(pass == 2) light1.render(renderer);
    }
    else{
      if(pass == 0) light1.render(renderer);
    }
  }
  
  if(state==-1){
    if(pass == 0) light1.render(renderer);
    if(lightF2(entity)){
      if(pass == 2) light2.render(renderer);
    }
    else{
      if(pass == 0) light2.render(renderer);
    }
  }
  
}

function lightF2(entity){
  if(entity==null) return true;
  var tick = entity.tick,
      f = tick % 8;
  if(f>0&&f<4) return false;
  return true;
}

function lightF1(entity){
  if(entity==null) return true;
  var tick = entity.tick,
      f = tick % 12;
  if(f>0&&f<2) return true;
  if(f>3&&f<6) return true;
  return false;
}