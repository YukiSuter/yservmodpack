var renderClass = "jp.ngt.rtm.render.SignalPartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2)
{
	body = renderer.registerParts(new Parts("body"));
	light = renderer.registerParts(new Parts("light"));
}

function render(entity, pass, par3)
{
  var signal,yaw;
  
  if(entity!=null){
    signal = entity.getSignal();
  }
  
  if(pass == 0) body.render(renderer);
  if(signal==1){
    if(pass == 2&&lightF(entity)) light.render(renderer);
  }
  if(signal==2){
    if(pass == 2)light.render(renderer);
  }
}

function lightF(entity){
  if(entity==null) return true;
  var tick = entity.tick,
      f = tick % 8;
  if(f<3) return false;
  return true;
}