var renderClass = "jp.ngt.rtm.render.SignalPartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2){
  body = renderer.registerParts(new Parts("body"));
  pole = renderer.registerParts(new Parts("pole"));
  body2 = renderer.registerParts(new Parts("body2"));
  light1 = renderer.registerParts(new Parts("light1"));
  light2 = renderer.registerParts(new Parts("light2"));
  light3 = renderer.registerParts(new Parts("light3"));
}

function lightT3(){
  var SysTime = renderer.getSystemTime(),
      CycleTime = SysTime % 90,
      signalState;
  if(CycleTime>=30&&CycleTime<=54){
    signalState = "Green";
  }
  else if(CycleTime>=54&&CycleTime<=57){
    signalState = "Yellow";
  }
  else if(CycleTime>=57&&CycleTime<=90){
    signalState = "Red";
  }
  else if(CycleTime>=0&&CycleTime<=30){
    signalState = "Red";
  }
  return signalState;
}

function flashing(entity){
  var Time = renderer.getTick(entity)%20,
      r;
  if(Time>=0&&Time<=10) r= true;
  if(Time>=10&&Time<=20) r= false;
  return r;
}

function render(entity, pass, par3){
  if(pass==0){
    body.render(renderer);
    body2.render(renderer);
    pole.render(renderer);
  }
  if(pass==2){
    switch(lightT3()){
      case "Green":light3.render(renderer);break;
      case "Yellow":light2.render(renderer);break;
      case "Red":light1.render(renderer);break;
    }
  }
}