var renderClass = "jp.ngt.rtm.render.SignalPartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);

function init(par1, par2){
  body = renderer.registerParts(new Parts("body"));
  pole = renderer.registerParts(new Parts("pole"));
  body2 = renderer.registerParts(new Parts("body2"));
  light1 = renderer.registerParts(new Parts("light1"));
  light2 = renderer.registerParts(new Parts("light2"));
  light3 = renderer.registerParts(new Parts("light3"));
}

function lightT2(){
  var SysTime = renderer.getSystemTime(),
      CycleTime = SysTime % 90,
      signalState;
  if(CycleTime>=45&&CycleTime<=65){
    signalState = "Green";
  }
  else if(CycleTime>=65&&CycleTime<=68){
    signalState = "Yellow";
  }
  else if(CycleTime>=68&&CycleTime<=90){
    signalState = "Red";
  }
  else if(CycleTime>=0&&CycleTime<=45){
    signalState = "Red";
  }
  return signalState;
}

function flashing(entity){
  var Time = renderer.getTick(entity)%10,
      r;
  if(Time>=0&&Time<=5) r= true;
  if(Time>=5&&Time<=10) r= false;
  return r;
}

function render(entity, pass, par3){
  if(pass==0){
    body.render(renderer);
    body2.render(renderer);
    pole.render(renderer);
  }
  if(pass==2){
    switch(lightT2()){
      case "Green":
        light1.render(renderer);
        break;
      case "Yellow":
        if(flashing(entity)==true) light1.render(renderer);
        break;
      case "Red":
        light2.render(renderer);
        break;
    }
  }
}