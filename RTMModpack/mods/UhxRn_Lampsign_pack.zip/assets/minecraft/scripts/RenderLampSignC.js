var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";

importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);



function init(par1, par2)
{
	body = renderer.registerParts(new Parts('body'));
	h01 = renderer.registerParts(new Parts('h01'));
	h02 = renderer.registerParts(new Parts('h02'));
	h03 = renderer.registerParts(new Parts('h03'));
	h04 = renderer.registerParts(new Parts('h04'));

	h11 = renderer.registerParts(new Parts('h11'));
	h12 = renderer.registerParts(new Parts('h12'));
	h13 = renderer.registerParts(new Parts('h13'));
	h14 = renderer.registerParts(new Parts('h14'));

	ModelName = renderer.getModelName();

}

function render(entity, pass, par3)
{

var flick = renderer.getTick(entity) % 30 ;

	GL11.glPushMatrix();

	if(pass == 0)
	{
	
		body.render(renderer);
		
		switch(true){
		case ModelName.contains("A") : h01.render(renderer) ; break ;
		case ModelName.contains("B") : h02.render(renderer) ; break ;
		case ModelName.contains("C") : h03.render(renderer) ; break ;
		case ModelName.contains("D") : h04.render(renderer) ; break ;
		default : h01.render(renderer) ; break ;
		}

	}else if(pass == 2){
	if(flick > 5){
		switch(true){
		case ModelName.contains("A") : h11.render(renderer) ; break ;
		case ModelName.contains("B") : h12.render(renderer) ; break ;
		case ModelName.contains("C") : h13.render(renderer) ; break ;
		case ModelName.contains("D") : h14.render(renderer) ; break ;
		default : h11.render(renderer) ; break ;
		}
	}

	}

	GL11.glPopMatrix();
}

