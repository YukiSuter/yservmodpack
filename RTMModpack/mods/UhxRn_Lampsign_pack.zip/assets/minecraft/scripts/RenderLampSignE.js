var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";

importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);



function init(par1, par2)
{
	body = renderer.registerParts(new Parts('body'));
	f01 = renderer.registerParts(new Parts('f01'));
	
	f11 = renderer.registerParts(new Parts('f11'));
	f12 = renderer.registerParts(new Parts('f12'));

	ModelName = renderer.getModelName();

}

function render(entity, pass, par3)
{

var flick = renderer.getTick(entity) % 30 ;

	GL11.glPushMatrix();

	if(pass == 0)
	{
	
		body.render(renderer);
		f01.render(renderer) ;
		
	}else if(pass == 2){
	if(15 > flick && flick > 5){
		f11.render(renderer) ;
		}else if(30 > flick && flick > 20){
		f12.render(renderer) ;
		}
	}


	GL11.glPopMatrix();
}

