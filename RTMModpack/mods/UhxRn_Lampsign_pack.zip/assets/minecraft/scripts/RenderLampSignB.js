var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";

importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);



function init(par1, par2)
{
	body = renderer.registerParts(new Parts('body'));
	h1 = renderer.registerParts(new Parts('h1'));

}

function render(entity, pass, par3)
{

	GL11.glPushMatrix();

	if(pass == 0)
	{
	
		body.render(renderer);

	}else if(pass == 2)
	{
	
			GL11.glPushMatrix();
			h1.render(renderer) ;
			GL11.glPopMatrix();

	}

	GL11.glPopMatrix();
}

