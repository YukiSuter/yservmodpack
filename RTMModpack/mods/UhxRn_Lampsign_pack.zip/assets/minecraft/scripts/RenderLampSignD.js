var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";

importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.renderer);
importPackage(Packages.jp.ngt.ngtlib.io);


function init(par1, par2)
{
	body = renderer.registerParts(new Parts('body'));
	LED1 = renderer.registerParts(new Parts('LED1'));
	LED2 = renderer.registerParts(new Parts('LED2'));

	s1 = renderer.registerParts(new Parts('s1'));
	s2 = renderer.registerParts(new Parts('s2'));
	s3 = renderer.registerParts(new Parts('s3'));
	s4 = renderer.registerParts(new Parts('s4'));
	s5 = renderer.registerParts(new Parts('s5'));
	s6 = renderer.registerParts(new Parts('s6'));
	s7 = renderer.registerParts(new Parts('s7'));
	s8 = renderer.registerParts(new Parts('s8'));
	s9 = renderer.registerParts(new Parts('s9'));
	s10 = renderer.registerParts(new Parts('s10'));
	
	ModelName = renderer.getModelName();

}

function render(entity, pass, par3)
{
	if (entity === null) return;

    	if (0 <= pass || pass <= 2) {
		//信号照会ブロック
		//色付き固焼き粘土：Blocks.field_150406_ce
		//色ガラス：Blocks.field_150399_cn
		//羊毛：Blocks.field_150325_L
		//カーペット：Blocks.field_150404_cg
		//板色ガラス：Blocks.field_150397_co
		//固焼き粘土：Blocks.field_150405_ch
		//ガラス：Blocks.field_150359_w
		//板ガラス：Blocks.field_150410_aZ
		
		var delaySign ;
		var delayLED ;
		
		if(ModelName.contains("A")){
		delaySign = Blocks.field_150399_cn ;
		delayLED =  Blocks.field_150359_w ;
		}else{
		delaySign = Blocks.field_150397_co ;
		delayLED =  Blocks.field_150410_aZ ;
		}
		
		var Sign = searchBlockAndMeta(entity, delaySign , null);
		var LED = searchBlockAndMeta(entity, delayLED , null);
		
		
		
		
	GL11.glPushMatrix();
	
		body.render(renderer);
		
		if(LED[0] == null){
		LED1.render(renderer) ;
		}else{
		LED2.render(renderer) ;
		}

		switch(Sign[1]){
		case 1 : s1.render(renderer) ; break ;
		case 2 : s2.render(renderer) ; break ;
		case 3 : s3.render(renderer) ; break ;
		case 4 : s4.render(renderer) ; break ;
		case 5 : s5.render(renderer) ; break ;
		case 6 : s6.render(renderer) ; break ;
		case 7 : s7.render(renderer) ; break ;
		case 8 : s8.render(renderer) ; break ;
		case 9 : s9.render(renderer) ; break ;
		case 10 : s10.render(renderer) ; break ;
		default : s1.render(renderer) ; break ;
		}
	GL11.glPopMatrix();
	
	}
}



/**
 * 真下32ブロック以内に指定のブロックが見つかれば、BlockとMetaDataを返します
 * metadataにnullを与えると全metadataが対象になる
 * 注意:metaの指定は色違い限定(羊毛,色ガラスなど)。木材,原木,階段ブロックなど,は不可 ※ver1.12.2
 * @param {TileEntity} entity
 * @param {Block} blockType
 * @param {number} metadata
 * @return {Array} [block(Block型), meta(Int型)]
 */
importPackage(Packages.jp.ngt.rtm); // RTMCore
importPackage(Packages.net.minecraft.init); // Blocks
importPackage(Packages.net.minecraft.util.math);  // BlockPos (1.12.2)

function searchBlockAndMeta(entity, blockType, metadata) {
    var version = RTMCore.VERSION;  // RTMバージョン取得
    var searchMaxCount = 32;// 判定深さ
    var world = entity.func_145831_w(); // world取得

    if (version.indexOf("1.7.10") != -1) {  // 1.7.10
        var x = Math.floor(entity.field_145851_c);
        var y = Math.floor(entity.field_145848_d);
        var z = Math.floor(entity.field_145849_e);

        for (var i = 1; i <= searchMaxCount; i++) {
            var block = world.func_147439_a(x, y - i, z);

            if (block === blockType) {
                if (metadata !== null) {
                    if (world.func_72805_g(x, y - i, z) === metadata) return [block, world.func_72805_g(x, y - i, z), i];
                }
                else return [block, world.func_72805_g(x, y - i, z), i];
            }
        }
    } else {    // 1.12.2
        var blockPos = entity.func_174877_v();
        var x = Math.floor(blockPos.func_177958_n());
        var y = Math.floor(blockPos.func_177956_o());
        var z = Math.floor(blockPos.func_177952_p());

        for (var i = 1; i <= searchMaxCount; i++) {
            var searchBlockPos = new BlockPos(x, y - i, z);
            var iBlockState = world.func_180495_p(searchBlockPos);
            var block = iBlockState.func_177230_c();
            var metaArray = iBlockState.func_177228_b().values().toArray(); // メタ情報取得(配列)

	    if (block === blockType) {
            	if (blockType == Blocks.field_150359_w || blockType == Blocks.field_150410_aZ || blockType == Blocks.field_150405_ch){
            		return [block, 0, i];
            	}else{
	                var meta = metaArray[0].func_176765_a();    // メタ取得(数値)

	                if (metadata !== null) {
	                    if (meta === metadata) return [block, meta, i];
	                }
	                else return [block, meta, i];
            	}
            }
        }
    }
    return [null, 0, 35];
}

