var renderClass = "jp.ngt.rtm.render.MachinePartsRenderer";

importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);



function init(par1, par2)
{
	body = renderer.registerParts(new Parts('body'));
	h0 = renderer.registerParts(new Parts('h0'));
	h1 = renderer.registerParts(new Parts('h1'));
	h2 = renderer.registerParts(new Parts('h2'));
	h3 = renderer.registerParts(new Parts('h3'));
	
	ModelName = renderer.getModelName();

}

function render(entity, pass, par3)
{

	GL11.glPushMatrix();

	if(pass == 0)
	{
	
		body.render(renderer);
		
		switch(true){
		case ModelName.contains("A") : h0.render(renderer) ; break ;
		case ModelName.contains("B") : h2.render(renderer) ; break ;
		default : h0.render(renderer) ; break ;
		}


	}else if(pass == 2)
	{
	
	var time = renderer.getMCHour() + renderer.getMCMinute() / 60.0 ;
	
	if(17.5 < time  || time < 6.5){
	
			switch(true){
			case ModelName.contains("A") : h1.render(renderer) ; break ;
			case ModelName.contains("B") : h3.render(renderer) ; break ;
			default : h1.render(renderer) ; break ;
		}
	 }

	}

	GL11.glPopMatrix();
}

